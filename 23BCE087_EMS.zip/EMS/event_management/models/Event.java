package event_management.models;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import event_management.exceptions.InvalidAttendeeException; 

public abstract class Event implements Serializable {
    protected String name;
    protected String location;
    protected Date date;
    protected List<Attendee> attendees;

    public Event(String name, String location, Date date) {
        this.name = name;
        this.location = location;
        this.date = date;
        this.attendees = new ArrayList<>();
    }

    public void addAttendee(Attendee attendee) throws InvalidAttendeeException {
        if (attendee == null) {
            throw new InvalidAttendeeException("Attendee cannot be null.");
        }
        attendees.add(attendee);
    }

    public abstract void displayEventDetails();

    public void displayEventDetails(boolean showAttendeeCount) {
        displayEventDetails();
        if (showAttendeeCount) {
            System.out.println("Number of Attendees:- " + attendees.size());
        }
    }
}
