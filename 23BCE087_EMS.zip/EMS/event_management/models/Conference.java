package event_management.models;
import java.util.Date;
import java.util.List;
public class Conference extends Event {
    private List<String> speakers;

    public Conference(String name, String location, Date date, List<String> speakers) {
        super(name, location, date);
        this.speakers = speakers;
    }

    @Override
    public void displayEventDetails() {
        System.out.println("Conference Name:- " + name);
        System.out.println("Location:- " + location);
        System.out.println("Date:- " + date);
        System.out.println("Speakers:- " + speakers);
    }
}
