package event_management.models;
import java.util.Date;
public class Wedding extends Event {
    private String bride;
    private String groom;

    public Wedding(String name, String location, Date date, String bride, String groom) {
        super(name, location, date);
        this.bride = bride;
        this.groom = groom;
    }

    @Override
    public void displayEventDetails() {
        System.out.println("Wedding Event:- " + name);
        System.out.println("Location:- " + location);
        System.out.println("Date:- " + date);
        System.out.println("Bride:- " + bride);
        System.out.println("Groom:- " + groom);
    }
}
