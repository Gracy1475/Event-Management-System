package event_management.models;
import java.io.Serializable;
public class Attendee implements Serializable {
    private String name;
    private String email;
    private String phone;

    public Attendee(String name, String email, String phone) {
        this.name = name;
        this.email = email;
        this.phone = phone;
    }

    public void displayAttendeeDetails() {
        System.out.println("Attendee Name:- " + name);
        System.out.println("Email:- " + email);
        System.out.println("Phone:- " + phone);
    }
}
