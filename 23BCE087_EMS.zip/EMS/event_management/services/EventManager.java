package event_management.services;
import event_management.models.Event;
import event_management.exceptions.InvalidAttendeeException;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class EventManager implements EventManagementSystem {
    private List<Event> events = new ArrayList<>();

    @Override
    public void createEvent(Event event) {
        events.add(event);
        System.out.println("Event created:- " + event);
    }

    @Override
    public void cancelEvent(Event event) {
        events.remove(event);
        System.out.println("Event cancelled:- " + event);
    }

    @Override
    public void displayAllEvents() {
        for (Event event : events) {
            event.displayEventDetails();
        }
    }

    public void saveEventsToFile(String filename) throws IOException {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(filename))) {
            out.writeObject(events);
            System.out.println("Events saved to file.");
        }
    }
    
    @SuppressWarnings("unchecked")
    public void loadEventsFromFile(String filename) throws IOException, ClassNotFoundException {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(filename))) {
            events = (List<Event>) in.readObject();
            System.out.println("Events loaded from file.");
        }
    }
}
