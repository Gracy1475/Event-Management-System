package event_management.services;
import event_management.models.Event;
public interface EventManagementSystem {
    void createEvent(Event event);
    void cancelEvent(Event event);
    void displayAllEvents();
}
