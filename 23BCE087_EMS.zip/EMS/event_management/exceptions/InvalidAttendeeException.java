package event_management.exceptions;
public class InvalidAttendeeException extends Exception {
    public InvalidAttendeeException(String message) {
        super(message);
    }
}
