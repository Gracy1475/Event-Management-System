package event_management.main;
import event_management.models.*;
import event_management.services.EventManager;
import event_management.exceptions.InvalidAttendeeException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class EventManagement {
    public static void main(String[] args) {
        EventManager manager = new EventManager();
        Scanner scanner = new Scanner(System.in);
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

        try {
            System.out.println("Welcome to Event Management System!");

            System.out.print("Enter event type (1 for Conference, 2 for Wedding):- ");
            int eventType = scanner.nextInt();
            scanner.nextLine();  

            System.out.print("Enter event name:- ");
            String name = scanner.nextLine();

            System.out.print("Enter event location:- ");
            String location = scanner.nextLine();

            System.out.print("Enter event date (dd/MM/yyyy):- ");
            String dateInput = scanner.nextLine();
            Date date = dateFormat.parse(dateInput);

            Event event;
            if (eventType == 1) {
                System.out.print("Enter speakers (comma-separated):- ");
                String speakersInput = scanner.nextLine();
                List<String> speakers = Arrays.asList(speakersInput.split(","));
                
                event = new Conference(name, location, date, speakers);
            } else if (eventType == 2) {
                System.out.print("Enter bride's name:- ");
                String bride = scanner.nextLine();

                System.out.print("Enter groom's name:- ");
                String groom = scanner.nextLine();

                event = new Wedding(name, location, date, bride, groom);
            } else {
                System.out.println("Invalid event type selected.");
                return;
            }

            manager.createEvent(event);
            System.out.print("Enter the number of attendees:- ");
            int attendeeCount = scanner.nextInt();
            scanner.nextLine();  

            for (int i = 0; i < attendeeCount; i++) {
                System.out.println("Enter details for Attendee #" + (i + 1) + ":-");
                System.out.print("Name:- ");
                String attendeeName = scanner.nextLine();

                System.out.print("Email:- ");
                String email = scanner.nextLine();

                System.out.print("Phone:- ");
                String phone = scanner.nextLine();

                Attendee attendee = new Attendee(attendeeName, email, phone);
                event.addAttendee(attendee);
            }

            manager.saveEventsToFile("events.ser");
            manager.loadEventsFromFile("events.ser");
            manager.displayAllEvents();
        } catch (InvalidAttendeeException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (ParseException e) {
            System.out.println("Invalid date format. Please use dd/MM/yyyy.");
        } catch (Exception e) {
            System.out.println("An unexpected error occurred: " + e.getMessage());
        } finally {
            scanner.close();
        }
    }
}
